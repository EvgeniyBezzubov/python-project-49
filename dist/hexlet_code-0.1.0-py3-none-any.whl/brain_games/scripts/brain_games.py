#!/usr/bin/env python3
import prompt
import random
import cli

def base():
    name = cli.main()


if __name__ == "__main__":
    base()
